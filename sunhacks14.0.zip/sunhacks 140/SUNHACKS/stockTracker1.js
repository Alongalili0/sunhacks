
let stockChart; // Define stockChart globally to manage its lifecycle

function processFile() {
    const initialAmountInput = document.getElementById('initialAmount');
    const positiveDaysInput = document.getElementById('positiveDays');
    const waitDaysInput = document.getElementById('waitDays');
    const resultsList = document.getElementById('resultsList');
    const ctx = document.getElementById('stockChart').getContext('2d');

    // Clear previous results
    resultsList.innerHTML = '';

    try {
        // Fetch the CSV file from the server with error handling
        fetch('Decimal_Change_Percentage.csv')
            .then(response => {
                if (!response.ok) {
                    throw new Error(`Network response was not ok: ${response.statusText}`);
                }
                return response.text();
            })
            .then(content => {
                const lines = content.split(/\r\n|\n/).filter(line => line.trim());
                let currentAmount = parseFloat(initialAmountInput.value);
                let positiveCount = 0;
                let waitCount = 0;
                let inMarket = true;  // Track if we are in the market (buying/selling)
                let firstDayValue = null;
                let finalDayValue = null;
                const positiveDays = parseInt(positiveDaysInput.value);
                const waitDays = parseInt(waitDaysInput.value);
                let amounts = [];
                let labels = [];

                if (isNaN(currentAmount)) {
                    throw new Error("Initial amount is not a valid number.");
                }

                lines.forEach((line, index) => {
                    const dayData = parseFloat(line);

                    if (isNaN(dayData)) {
                        console.error(`Skipping invalid data on day ${index + 1}: ${line}`);
                        return; // Skip invalid data
                    }

                    // Set the first day value
                    if (firstDayValue === null) {
                        firstDayValue = currentAmount;
                    }

                    if (waitCount > 0) {
                        waitCount--;  // If in waiting period, reduce wait count
                    } else if (inMarket) {
                        // Handle consecutive positive days
                        if (dayData > 0) {
                            positiveCount++;
                            if (positiveCount >= positiveDays) {
                                // Sell condition met, sell and enter waiting period
                                inMarket = false;
                                waitCount = waitDays;
                                if (waitDays === 0) {
                                    inMarket = true;  // Reenter the market immediately if waitDays = 0
                                }
                            }
                        } else {
                            positiveCount = 0;  // Reset if we hit a negative day
                        }

                        // Update current amount based on the percentage change
                        currentAmount += currentAmount * dayData;
                    } else {
                        // Reenter the market after waiting period or immediately if waitDays = 0
                        if (waitCount === 0) {
                            inMarket = true;
                        }
                    }

                    // Track the final day's value
                    finalDayValue = currentAmount;
                    
                    // Convert days to "years, days" format
                    const years = Math.floor(index / 365);
                    const days = index % 365;
                    labels.push(`Year ${years}, Day ${days}`);
                    
                    amounts.push(currentAmount);
                });

                // If finalDayValue is still null, no valid data was processed
                if (finalDayValue === null || isNaN(finalDayValue)) {
                    resultsList.innerHTML += `<li>Error: No valid data processed, or final amount is not a number.</li>`;
                } else {
                    const totalDays = labels.length;
                    const totalYears = Math.floor(totalDays / 365);
                    const remainingDays = totalDays % 365;

                    // Display the first and last day values in "years, days" format
                    resultsList.innerHTML += `
                        <li style="font-weight:bold;">Amount after Year 0, Day 1: ${firstDayValue.toFixed(2)}</li>
                        <li style="font-weight:bold;">Amount after Year ${totalYears}, Day ${remainingDays}: ${finalDayValue.toFixed(2)}</li>
                    `;

                    // Update the chart to show all data points
                    if (stockChart) {
                        stockChart.destroy();
                    }
                    stockChart = new Chart(ctx, {
                        type: 'line',
                        data: {
                            labels: labels,
                            datasets: [{
                                label: 'Account Value',
                                data: amounts,
                                borderColor: 'rgba(75, 192, 192, 1)',
                                borderWidth: 2,
                                fill: false
                            }]
                        },
                        options: {
                            responsive: true,
                            title: {
                                display: true,
                                text: 'Portfolio Performance Over Time'
                            },
                            scales: {
                                xAxes: [{
                                    display: true,
                                    scaleLabel: {
                                        display: true,
                                        labelString: 'Years, Days'
                                    }
                                }],
                                yAxes: [{
                                    display: true,
                                    scaleLabel: {
                                        display: true,
                                        labelString: 'Value'
                                    },
                                    ticks: {
                                        beginAtZero: true
                                    }
                                }]
                            }
                        }
                    });
                }
            })
            .catch(error => {
                console.error('Error fetching or processing data:', error);
                resultsList.innerHTML += `<li>Error: ${error.message}</li>`;
            });
    } catch (e) {
        console.error('Critical error during processing:', e);
        resultsList.innerHTML += `<li>Critical error: ${e.message}</li>`;
    }
}
